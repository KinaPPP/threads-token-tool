// Pure helpers: no storage, logs, or credentials bundled with the extension.
export const TOKEN_SCOPES = Object.freeze([
  'threads_basic',
  'threads_content_publish',
  'threads_profile_discovery'
]);

export function makeAuthUrl(appId, redirectUri, state) {
  if (!/^\d+$/.test(appId)) throw new Error('invalid app id');
  if (!state || state.length < 32) throw new Error('invalid state');

  const url = new URL('https://threads.net/oauth/authorize');
  url.searchParams.set('client_id', appId);
  url.searchParams.set('redirect_uri', redirectUri);
  url.searchParams.set('scope', TOKEN_SCOPES.join(','));
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('state', state);
  return url.href;
}

export function parseCallback(callbackUrl, expectedRedirectUri, expectedState) {
  const callback = new URL(callbackUrl);
  const expected = new URL(expectedRedirectUri);
  if (callback.origin !== expected.origin || callback.pathname !== expected.pathname) {
    throw new Error('redirect_mismatch');
  }
  if (!expectedState || callback.searchParams.get('state') !== expectedState) {
    throw new Error('state_mismatch');
  }
  if (callback.searchParams.has('error') || callback.searchParams.has('error_reason')) {
    throw new Error('oauth_denied');
  }
  const code = callback.searchParams.get('code')?.replace(/#_$/, '');
  if (!code) throw new Error('missing_code');
  return code;
}

export function shortTokenBody({ appId, appSecret, redirectUri, code }) {
  const params = new URLSearchParams();
  params.set('client_id', appId);
  params.set('client_secret', appSecret);
  params.set('grant_type', 'authorization_code');
  params.set('redirect_uri', redirectUri);
  params.set('code', code);
  return params;
}

// Metaの長期交換APIへ直接HTTPS通信するためのURL。
// このURLにはSecretと短期トークンが含まれるため、表示・ログ出力・外部送信をしないこと。
export function longTokenRequestUrl(appSecret, shortToken) {
  const url = new URL('https://graph.threads.net/access_token');
  url.searchParams.set('grant_type', 'th_exchange_token');
  url.searchParams.set('client_secret', appSecret);
  url.searchParams.set('access_token', shortToken);
  return url.href;
}
