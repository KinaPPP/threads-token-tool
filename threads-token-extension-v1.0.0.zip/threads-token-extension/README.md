# Threadsトークン 取トーくん

**Threads Token ShuTo-kun**  
v1.0.0

利用者自身のMetaアプリを使い、ThreadsのOAuth認証から長期アクセストークン取得までをChrome拡張だけで行う小さなツールです。

公開CORSプロキシやKINA管理の中継サーバーは使用しません。App ID・App Secret・取得したトークンも拡張機能のストレージへ保存しません。

## 導入

1. 配布ZIPを展開します。
2. Chromeで `chrome://extensions` を開きます。
3. 「デベロッパー モード」をONにします。
4. 「パッケージ化されていない拡張機能を読み込む」を押します。
5. 展開した `threads-token-extension` フォルダを選択します。
6. 拡張機能アイコンから **Threadsトークン 取トーくん** を開きます。

## Meta側の設定

1. 取トーくんに表示された「コールバックURLをリダイレクト」をコピーします。
2. Meta for DevelopersのThreads API設定へ貼り付けます。
3. 貼り付けると下に同じURLの候補が表示されるので、その候補をクリックして確定してから保存します。貼り付けただけでは未登録です。
4. Threads App IDとThreads App Secretを取トーくんへ入力します。
5. 「Threadsと連携してトークンを取得する」を押します。
6. 成功すると長期Access Token、Threads User ID、有効期限の目安を表示します。

「コールバックURLをアンインストール」「コールバックURLを削除」は、個人利用・テスター利用では空欄の状態でも長期トークン取得まで実機確認しています。Meta側で入力を求められた場合はMetaの案内に従ってください。

## 取得する権限

取トーくんは次の3権限を固定で要求します。

- `threads_basic`
- `threads_content_publish`
- `threads_profile_discovery`

クロスポスト系ツールとシンプルまるごとZIPで共通利用しやすくするための構成です。使用先が利用しない権限は、そのアプリからは使用されません。

## セキュリティ方針

- `chrome.storage.local` / `chrome.storage.sync` / `sessionStorage` 等へApp ID、App Secret、認証コード、トークンを保存しません。
- App SecretはMeta公式APIへのトークン交換に必要な間だけ使用します。
- 長期トークン取得成功後、App IDとApp Secretは画面から消去します。
- 公開CORSプロキシを使用しません。
- App Secret、認可コード、アクセストークンをConsoleへ出力しません。
- Meta APIのエラー本文をそのまま画面へ表示しません。
- クリップボードへのコピーは利用者が明示的にボタンを押した場合だけ行います。
- このツール自身は長期トークンの自動更新を行いません。

## 実機確認

Chrome + Meta Threads APIの実環境で、次を確認しています。

- `chrome.identity.launchWebAuthFlow()` 用の `https://<拡張ID>.chromiumapp.org/threads` をMetaのリダイレクトURLとして登録できる。
- Threads OAuth認証に成功する。
- 短期トークンから長期アクセストークンへ交換できる。
- 公開CORSプロキシや中継サーバーは不要。
- アンインストール／削除コールバックURLを空欄にした個人利用・テスター環境でも長期トークン取得まで成功する。

## ZIP構成

配布ZIP名にはバージョンを付けますが、ZIP内部の親フォルダ名は固定です。

```text
threads-token-extension/
  manifest.json
  app.html
  app.js
  style.css
  worker.js
  api.mjs
  oauth-core.mjs
  README.md
```

ソースコードにはテスト用ファイルも含まれます。
