import { makeAuthUrl, parseCallback, TOKEN_SCOPES } from './oauth-core.mjs';

const $ = id => document.getElementById(id);
const redirectUri = chrome.identity.getRedirectURL('threads');
$('redirect-uri').value = redirectUri;

let tokenInMemory = null;
let userIdInMemory = null;
let busy = false;
let completed = false;

function setBusy(value, status = '') {
  busy = value;
  $('auth').disabled = value || completed;
  $('status').textContent = status;
}

function setInputLocked(locked) {
  $('app-id').disabled = locked;
  $('app-secret').disabled = locked;
  $('toggle-secret').disabled = locked;
}

function clearCredentialsAndLock() {
  $('app-id').value = '';
  $('app-secret').value = '';
  $('app-secret').classList.add('masked');
  $('toggle-secret').textContent = '表示';
  $('toggle-secret').setAttribute('aria-pressed', 'false');
  completed = true;
  setInputLocked(true);
  $('auth').disabled = true;
}

function unlockForRestart() {
  completed = false;
  setInputLocked(false);
  $('auth').disabled = false;
}

function clearResult() {
  tokenInMemory = null;
  userIdInMemory = null;
  $('result-token').value = '';
  $('result-user').value = '';
  $('result-expires').textContent = '';
  $('result-panel').classList.add('hidden');
  $('result-token').classList.add('masked');
  $('show-token').textContent = '表示';
  $('show-token').setAttribute('aria-pressed', 'false');
}

function toggleMask(inputId, buttonId) {
  const input = $(inputId);
  const button = $(buttonId);
  input.classList.toggle('masked');
  const visible = !input.classList.contains('masked');
  button.textContent = visible ? '隠す' : '表示';
  button.setAttribute('aria-pressed', String(visible));
}

$('toggle-secret').addEventListener('click', () => toggleMask('app-secret', 'toggle-secret'));
$('show-token').addEventListener('click', () => toggleMask('result-token', 'show-token'));

async function copyExplicit(value, button) {
  if (!value) return;
  try {
    await navigator.clipboard.writeText(value);
    const old = button.textContent;
    button.textContent = 'コピー済み';
    setTimeout(() => {
      if (button.isConnected) button.textContent = old;
    }, 1500);
  } catch {
    $('status').textContent = 'コピーできませんでした。ブラウザのクリップボード権限を確認してください。';
  }
}

$('copy-redirect').addEventListener('click', () => copyExplicit(redirectUri, $('copy-redirect')));
$('copy-token').addEventListener('click', () => copyExplicit(tokenInMemory, $('copy-token')));
$('copy-user').addEventListener('click', () => copyExplicit(userIdInMemory, $('copy-user')));

function humanError(error) {
  if (error?.message === 'state_mismatch') return '認証の安全確認（state）が一致しません。最初から再認証してください。';
  if (error?.message === 'redirect_mismatch') return '認証のリダイレクト先が予期したURLと異なります。';
  if (error?.message === 'oauth_denied') return 'Threads側で認証が拒否またはキャンセルされました。';
  if (error?.message === 'missing_code') return '認可コードが取得できませんでした。Meta側の設定を確認してください。';
  if (error?.stage) {
    const names = {
      short_network: '短期トークン取得時の通信失敗',
      short: 'Metaの短期トークン応答エラー',
      short_response: '短期トークンの応答形式が不正',
      long_network: '長期トークン取得時の通信失敗',
      long: 'Metaの長期トークン応答エラー',
      long_response: '長期トークンの応答形式が不正',
      redirect: '認証用リダイレクトURIが異なる',
      input: '入力値が不正',
      unexpected: '予期しない処理エラー'
    };
    const code = error.metaCode ? ` / Metaコード ${error.metaCode}` : '';
    const status = error.status ? ` / HTTP ${error.status}` : '';
    return `${names[error.stage] ?? '交換処理失敗'}${status}${code}。Secretやトークンはエラー表示に含めません。`;
  }
  return 'OAuth認証を完了できませんでした。Metaの許可設定と登録URIを確認してください。';
}

async function startAuth() {
  if (busy) return;
  clearResult();

  let appId = $('app-id').value.trim();
  let appSecret = $('app-secret').value.trim();
  if (!/^\d+$/.test(appId) || !appSecret) {
    $('status').textContent = 'App IDとApp Secretを確認してください。';
    return;
  }

  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  const state = Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');

  setBusy(true, 'Threadsの認証画面を開いています…');
  try {
    const url = makeAuthUrl(appId, redirectUri, state);
    const callbackUrl = await chrome.identity.launchWebAuthFlow({ url, interactive: true });
    if (!callbackUrl) throw new Error('missing_code');

    const code = parseCallback(callbackUrl, redirectUri, state);
    setBusy(true, 'Metaで短期・長期トークンを交換しています…');

    const response = await chrome.runtime.sendMessage({
      type: 'EXCHANGE_TOKEN',
      payload: { appId, appSecret, code, redirectUri }
    });

    // Secretはサービスワーカーから応答が返った時点で入力欄・ローカル変数から破棄する。
    $('app-secret').value = '';
    appSecret = '';

    if (!response?.ok) throw response ?? { stage: 'unexpected' };

    tokenInMemory = response.data.accessToken;
    userIdInMemory = response.data.userId;
    $('result-token').value = tokenInMemory;
    $('result-user').value = userIdInMemory ?? 'Meta応答にIDなし';

    const seconds = response.data.expiresIn;
    $('result-expires').textContent = seconds
      ? `有効期限の目安：${new Date(Date.now() + seconds * 1000).toLocaleString('ja-JP')}（Meta応答の expires_in から計算）`
      : '有効期限：Meta応答から取得できませんでした。';

    clearCredentialsAndLock();
    appId = '';
    appSecret = '';

    $('result-panel').classList.remove('hidden');
    $('result-panel').scrollIntoView({ behavior: 'smooth', block: 'start' });
    setBusy(false, `トークンを取得しました（${TOKEN_SCOPES.length}権限）。App ID / App Secretは画面から消去しました。`);
  } catch (error) {
    $('app-secret').value = '';
    appSecret = '';
    setBusy(false, humanError(error));
  }
}

$('auth').addEventListener('click', startAuth);
['app-id', 'app-secret'].forEach(id => {
  $(id).addEventListener('keydown', event => {
    if (event.key === 'Enter') {
      event.preventDefault();
      startAuth();
    }
  });
});

$('restart').addEventListener('click', () => {
  clearResult();
  unlockForRestart();
  $('status').textContent = '';
  $('app-id').focus();
  $('input-panel').scrollIntoView({ behavior: 'smooth', block: 'start' });
});

window.addEventListener('pagehide', () => {
  clearResult();
  $('app-id').value = '';
  $('app-secret').value = '';
});
