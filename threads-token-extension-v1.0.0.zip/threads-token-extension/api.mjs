import { shortTokenBody, longTokenRequestUrl } from './oauth-core.mjs';

export class ExchangeError extends Error {
  constructor(stage, status = 0, metaCode = null) {
    super(stage);
    this.stage = stage;
    this.status = status;
    this.metaCode = Number.isInteger(metaCode) ? metaCode : null;
  }
}

async function readJsonResponse(response, stage) {
  let body;
  try { body = await response.json(); }
  catch { throw new ExchangeError(stage, response.status); }
  if (!response.ok) {
    const metaCode = Number(body?.error?.code ?? body?.error_code ?? body?.code);
    throw new ExchangeError(stage, response.status, Number.isInteger(metaCode) ? metaCode : null);
  }
  return body;
}

export async function exchangeToken({ appId, appSecret, code, redirectUri }, fetchImpl = fetch) {
  if (!/^\d+$/.test(appId) || typeof appSecret !== 'string' || !appSecret ||
      typeof code !== 'string' || !code || typeof redirectUri !== 'string') {
    throw new ExchangeError('input');
  }
  let shortResponse;
  try {
    shortResponse = await fetchImpl('https://graph.threads.net/oauth/access_token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: shortTokenBody({ appId, appSecret, redirectUri, code }).toString(),
      credentials: 'omit', cache: 'no-store', redirect: 'error', referrerPolicy: 'no-referrer'
    });
  } catch { throw new ExchangeError('short_network'); }
  const shortData = await readJsonResponse(shortResponse, 'short');
  if (typeof shortData?.access_token !== 'string' || !shortData.access_token) {
    throw new ExchangeError('short_response');
  }
  const userId = shortData.user_id == null ? null : String(shortData.user_id);
  let longResponse;
  try {
    longResponse = await fetchImpl(longTokenRequestUrl(appSecret, shortData.access_token), {
      method: 'GET', credentials: 'omit', cache: 'no-store', redirect: 'error', referrerPolicy: 'no-referrer'
    });
  } catch { throw new ExchangeError('long_network'); }
  const longData = await readJsonResponse(longResponse, 'long');
  if (typeof longData?.access_token !== 'string' || !longData.access_token) {
    throw new ExchangeError('long_response');
  }
  const expiresIn = Number(longData.expires_in);
  return {
    accessToken: longData.access_token,
    userId,
    expiresIn: Number.isFinite(expiresIn) && expiresIn > 0 ? expiresIn : null
  };
}
