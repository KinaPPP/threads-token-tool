import { exchangeToken, ExchangeError } from './api.mjs';

chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL('app.html') });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Only our own extension tab can invoke a token exchange.
  if (message?.type !== 'EXCHANGE_TOKEN' || sender.id !== chrome.runtime.id ||
      sender.url !== chrome.runtime.getURL('app.html')) return false;
  const expectedRedirect = chrome.identity.getRedirectURL('threads');
  if (message.payload?.redirectUri !== expectedRedirect) {
    sendResponse({ ok: false, stage: 'redirect' });
    return false;
  }
  (async () => {
    try {
      const data = await exchangeToken(message.payload);
      sendResponse({ ok: true, data });
    } catch (error) {
      const isKnown = error instanceof ExchangeError;
      // Never return Meta error_message: it can echo confidential request values.
      sendResponse({ ok: false, stage: isKnown ? error.stage : 'unexpected',
        status: isKnown ? error.status : 0,
        metaCode: isKnown ? error.metaCode : null });
    }
  })();
  return true;
});
